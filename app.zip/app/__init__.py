from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_mail import Mail
# from flask_wtf import CSRFProtect  # ⛔ Protection CSRF temporairement désactivée

db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'main.login'
mail = Mail()
# csrf = CSRFProtect()  # ⛔ Objet CSRF désactivé temporairement

def create_app():
    app = Flask(__name__)
    app.config.from_object('config')

    db.init_app(app)
    migrate = Migrate(app, db)
    login_manager.init_app(app)
    mail.init_app(app)
    # csrf.init_app(app)  # ⛔ Désactivation temporaire de CSRF

    with app.app_context():
        from . import routes, models
        from app.routes import bp as main_bp
        app.register_blueprint(main_bp)

    return app
