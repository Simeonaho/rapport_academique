print("Route / appelée")

from flask import Blueprint, render_template, flash, redirect, url_for, request, send_file, make_response
from flask_login import login_user, logout_user, current_user, login_required
import io 
from io import BytesIO, TextIOWrapper
from reportlab.pdfgen import canvas
import csv
import zipfile
from flask_mail import Message
from app import db, mail
from app.forms import RegistrationForm, LoginForm, AjouterEtudiantForm, AjouterNoteForm, ContactForm, ExportCSVForm
from app.models import Utilisateur, Note, MessageContact
from app.forms import RechercheEtudiantForm  # ajouter l'import
from flask_wtf.csrf import generate_csrf


bp = Blueprint('main', __name__)

@bp.after_app_request
def set_csp_headers(response):
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline'; "
        "img-src 'self' data:; "
        "font-src 'self'; "
        "connect-src 'self'; "
        "frame-ancestors 'none';"
    )
    return response

@bp.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('main.admin_dashboard'))
        elif current_user.role == 'etudiant':
            return redirect(url_for('main.etudiant_dashboard'))
    return render_template('index.html')

@bp.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        # Vérifie que l’étudiant a été préalablement ajouté par l’admin
        etudiant = Utilisateur.query.filter_by(matricule=form.matricule.data, role='etudiant').first()

        if not etudiant:
            flash("Ce matricule n'existe pas encore. Veuillez contacter l'administrateur.", 'danger')
            return redirect(url_for('main.register'))

        if etudiant.email:
            flash("Ce matricule a déjà été utilisé pour s’inscrire.", 'danger')
            return redirect(url_for('main.register'))

        if etudiant.nom.lower() != form.nom.data.lower():
            flash("Le nom ne correspond pas au matricule fourni.", 'danger')
            return redirect(url_for('main.register'))

        email_existant = Utilisateur.query.filter_by(email=form.email.data).first()
        if email_existant:
            flash('Un compte avec cet email existe déjà.', 'danger')
            return redirect(url_for('main.register'))

        # Mise à jour des identifiants de connexion
        etudiant.email = form.email.data
        etudiant.set_password(form.mot_de_passe.data)
        db.session.commit()

        flash('Inscription réussie. Vous pouvez maintenant vous connecter.', 'success')
        return redirect(url_for('main.login'))

    return render_template('register.html', form=form)

@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.role == 'admin':
            return redirect(url_for('main.admin_dashboard'))
        elif current_user.role == 'etudiant':
            return redirect(url_for('main.etudiant_dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        utilisateur = Utilisateur.query.filter_by(email=form.email.data).first()
        if utilisateur is None or not utilisateur.check_password(form.mot_de_passe.data):
            flash('Email ou mot de passe incorrect.', 'danger')
            return redirect(url_for('main.login'))

        login_user(utilisateur)
        flash('Connexion réussie.', 'success')
        if utilisateur.role == 'admin':
            return redirect(url_for('main.admin_dashboard'))
        elif utilisateur.role == 'etudiant':
            return redirect(url_for('main.etudiant_dashboard'))
        else:
            return redirect(url_for('main.index'))

    return render_template('login.html', form=form)

@bp.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Déconnexion réussie.', 'info')
    return redirect(url_for('main.login'))


@bp.route('/admin/dashboard')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash("Accès réservé à l'administrateur", 'danger')
        return redirect(url_for('main.login'))

    form = AjouterEtudiantForm()
    note_form = AjouterNoteForm()
    etudiants = Utilisateur.query.filter_by(role='etudiant').all()

    # ➕ Comptage des messages non répondus
    messages_non_lus = MessageContact.query.filter_by(reponse=None).count()

    export_form = ExportCSVForm()

    return render_template(
        'admin_dashboard.html',
        nom=current_user.nom,
        form=form,
        note_form=note_form,
        etudiants=etudiants,
        messages_non_lus=messages_non_lus,
        export_form=export_form
    )

@bp.route('/admin/ajouter_etudiant_page', methods=['GET', 'POST'])
@login_required
def ajouter_etudiant_page():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", "danger")
        return redirect(url_for('main.login'))

    form = AjouterEtudiantForm()

    if form.validate_on_submit():
        matricule_existant = Utilisateur.query.filter_by(matricule=form.matricule.data).first()
        if matricule_existant:
            flash("Ce matricule est déjà utilisé.", "danger")
        else:
            etudiant = Utilisateur(
                nom=form.nom.data,
                matricule=form.matricule.data,
                filiere=form.filiere.data,
                annee=form.annee.data,
                role='etudiant',
                email=None
            )
            etudiant.set_password("changeme123")  # mot de passe temporaire
            db.session.add(etudiant)
            db.session.commit()
            flash("Étudiant ajouté avec succès avec un mot de passe temporaire.", "success")
            return redirect(url_for('main.admin_dashboard'))

    return render_template("ajouter_etudiant.html", form=form)

@bp.route('/admin/ajouter_note', methods=['GET', 'POST'])
@login_required
def ajouter_note_page():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    form = AjouterNoteForm()
    if form.validate_on_submit():
        etudiant = Utilisateur.query.filter_by(matricule=form.matricule.data).first()
        if not etudiant:
            flash("Aucun étudiant trouvé avec ce matricule.", 'danger')
        else:
            note = Note(
                matiere=form.matiere.data,
                type=form.type.data,
                note=form.note.data,
                credit=form.credit.data,
                etudiant_id=etudiant.id
            )
            db.session.add(note)
            db.session.commit()
            flash("Note ajoutée avec succès.", 'success')
            return redirect(url_for('main.admin_dashboard'))

    return render_template("ajouter_note.html", form=form)


@bp.route('/etudiant/dashboard')
@login_required
def etudiant_dashboard():
    if current_user.role != 'etudiant':
        flash("Accès réservé aux étudiants", 'danger')
        return redirect(url_for('main.login'))

    resultats = Note.query.filter_by(etudiant_id=current_user.id).all()
    moyenne = None
    credits_obtenus = 0
    credits_total = 60.0

    if resultats:
        total_notes = sum(note.note for note in resultats)
        moyenne = round(total_notes / len(resultats), 2)
        credits_obtenus = sum(note.credit for note in resultats if note.note >= 10)

    return render_template(
        'etudiant_dashboard.html',
        nom=current_user.nom,
        resultats=resultats,
        moyenne=moyenne,
        credits_obtenus=credits_obtenus,
        credits_total=credits_total
    )

@bp.route('/route_by_role')
@login_required
def route_by_role():
    if current_user.role == 'admin':
        return redirect(url_for('main.admin_dashboard'))
    else:
        return redirect(url_for('main.etudiant_dashboard'))

@bp.route('/ajouter_etudiant', methods=['POST'])
@login_required
def ajouter_etudiant():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    form = AjouterEtudiantForm()
    if form.validate_on_submit():
        matricule_existant = Utilisateur.query.filter_by(matricule=form.matricule.data).first()
        if matricule_existant:
            flash("Ce matricule est déjà utilisé.", 'danger')
        else:
            etudiant = Utilisateur(
                nom=form.nom.data,
                matricule=form.matricule.data,
                filiere=form.filiere.data,
                annee=form.annee.data,
                role='etudiant',
                email=None
            )
            # Mot de passe par défaut
            etudiant.set_password("changeme123")
            db.session.add(etudiant)
            db.session.commit()
            flash("Étudiant ajouté avec succès avec un mot de passe temporaire. Il devra s'inscrire pour définir son email et son mot de passe.", 'success')
    else:
        flash("Erreur dans le formulaire. Veuillez vérifier les champs.", 'danger')

    return redirect(url_for('main.admin_dashboard'))


@bp.route('/ajouter_note', methods=['POST'])
@login_required
def ajouter_note():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    form = AjouterNoteForm()
    if form.validate_on_submit():
        etudiant = Utilisateur.query.filter_by(matricule=form.matricule.data).first()
        if not etudiant:
            flash("Aucun étudiant trouvé avec ce matricule.", 'danger')
            return redirect(url_for('main.admin_dashboard'))

        note = Note(
            matiere=form.matiere.data,
            type=form.type.data,
            note=form.note.data,
            credit=form.credit.data,
            etudiant_id=etudiant.id
        )
        db.session.add(note)
        db.session.commit()
        flash("Note ajoutée avec succès.", 'success')
    else:
        flash("Erreur dans le formulaire de note.", 'danger')

    return redirect(url_for('main.admin_dashboard'))

@bp.route('/admin/notes', methods=['GET', 'POST'])
@login_required
def consulter_notes_etudiant():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    if request.method == 'GET':
        # Affiche un formulaire de recherche par matricule (si tu veux en GET)
        return render_template('consulter_notes.html')

    # Traitement du formulaire envoyé en POST
    matricule = request.form.get('matricule')
    etudiant = Utilisateur.query.filter_by(matricule=matricule, role='etudiant').first()

    if not etudiant:
        flash("Aucun étudiant trouvé avec ce matricule.", 'danger')
        return redirect(url_for('main.admin_dashboard'))

    resultats = Note.query.filter_by(etudiant_id=etudiant.id).all()
    moyenne = round(sum(n.note for n in resultats) / len(resultats), 2) if resultats else None
    credits_obtenus = sum(n.credit for n in resultats if n.note >= 10)
    credits_total = 60.0

    return render_template(
        'etudiant_dashboard.html',
        nom=etudiant.nom,
        resultats=resultats,
        moyenne=moyenne,
        credits_obtenus=credits_obtenus,
        credits_total=credits_total,
        matricule=etudiant.matricule
    )


@bp.route('/admin/etudiants')
@login_required
def liste_etudiants():
    if current_user.role != 'admin':
        flash("Accès réservé à l'administrateur", 'danger')
        return redirect(url_for('main.login'))

    etudiants = Utilisateur.query.filter_by(role='etudiant').all()
    return render_template('liste_etudiants.html', etudiants=etudiants)

@bp.route('/admin/resultats/pdf/<matricule>')
@login_required
def telecharger_resultats_pdf_admin(matricule):
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    etudiant = Utilisateur.query.filter_by(matricule=matricule, role='etudiant').first()
    if not etudiant:
        flash("Aucun étudiant trouvé avec ce matricule.", 'danger')
        return redirect(url_for('main.admin_dashboard'))

    notes = Note.query.filter_by(etudiant_id=etudiant.id).all()
    moyenne = round(sum(n.note for n in notes) / len(notes), 2) if notes else None
    credits_obtenus = sum(n.credit for n in notes if n.note >= 10)
    credits_total = 60.0

    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, 800, f"Résultats de : {etudiant.nom} ({etudiant.matricule})")
    p.setFont("Helvetica", 12)

    y = 770
    for note in notes:
        p.drawString(60, y, f"{note.matiere} ({note.type}) : {note.note} / 20 - Crédit : {note.credit}")
        y -= 20
        if y < 50:
            p.showPage()
            y = 800

    if moyenne is not None:
        y -= 20
        p.setFont("Helvetica-Bold", 12)
        p.drawString(60, y, f"Moyenne générale : {moyenne} / 20")
        y -= 20
        p.drawString(60, y, f"Crédits obtenus : {credits_obtenus} / {credits_total}")

    p.showPage()
    p.save()
    buffer.seek(0)

    return send_file(buffer, as_attachment=True, download_name=f"{etudiant.matricule}_resultats.pdf", mimetype='application/pdf')
@bp.route('/etudiant/resultats/pdf')
@login_required
def telecharger_resultats_pdf():
    if current_user.role != 'etudiant':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    notes = Note.query.filter_by(etudiant_id=current_user.id).all()
    moyenne = round(sum(n.note for n in notes) / len(notes), 2) if notes else None
    credits_obtenus = sum(n.credit for n in notes if n.note >= 10)
    credits_total = 60.0

    buffer = BytesIO()
    p = canvas.Canvas(buffer)
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, 800, f"Résultats de : {current_user.nom} ({current_user.matricule})")
    p.setFont("Helvetica", 12)

    y = 770
    for note in notes:
        p.drawString(60, y, f"{note.matiere} ({note.type}) : {note.note} / 20 - Crédit : {note.credit}")
        y -= 20
        if y < 50:
            p.showPage()
            y = 800

    if moyenne is not None:
        y -= 20
        p.setFont("Helvetica-Bold", 12)
        p.drawString(60, y, f"Moyenne générale : {moyenne} / 20")
        y -= 20
        p.drawString(60, y, f"Crédits obtenus : {credits_obtenus} / {credits_total}")

    p.showPage()
    p.save()
    buffer.seek(0)

    return send_file(buffer, as_attachment=True, download_name=f"{current_user.matricule}_resultats.pdf", mimetype='application/pdf')
@bp.route('/admin/supprimer_etudiant', methods=['POST'])
@login_required
def supprimer_etudiant():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    matricule = request.form.get('matricule')
    etudiant = Utilisateur.query.filter_by(matricule=matricule, role='etudiant').first()

    if not etudiant:
        flash("Étudiant introuvable.", 'danger')
        return redirect(url_for('main.admin_dashboard'))

    # Supprimer d'abord ses notes
    Note.query.filter_by(etudiant_id=etudiant.id).delete()

    # Ensuite supprimer l'étudiant
    db.session.delete(etudiant)
    db.session.commit()

    flash("Étudiant et ses notes supprimés avec succès.", 'success')
    return redirect(url_for('main.admin_dashboard'))
@bp.route('/admin/supprimer_note', methods=['POST'])
@login_required
def supprimer_note():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    note_id = request.form.get('note_id')
    note = Note.query.get(note_id)

    if not note:
        flash("Note introuvable.", 'danger')
        return redirect(url_for('main.admin_dashboard'))

    db.session.delete(note)
    db.session.commit()

    flash("Note supprimée avec succès.", 'success')
    return redirect(request.referrer or url_for('main.admin_dashboard'))

@bp.route('/admin/update_notes', methods=['POST'])
@login_required
def update_notes():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    etudiant_id = request.form.get('etudiant_id')
    notes = Note.query.filter_by(etudiant_id=etudiant_id).all()

    for note in notes:
        note.matiere = request.form.get(f"matiere_{note.id}")
        note.type = request.form.get(f"type_{note.id}")
        note.note = float(request.form.get(f"note_{note.id}"))
        note.credit = float(request.form.get(f"credit_{note.id}"))

    db.session.commit()
    flash("Notes mises à jour avec succès.", 'success')
    return redirect(url_for('main.modifier_notes'))


@bp.route('/admin/modifier_notes', methods=['GET', 'POST'])
@login_required
def modifier_notes():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    form = RechercheEtudiantForm()
    etudiant = None
    notes = []
    matricule = None

    if form.validate_on_submit():
        matricule = form.matricule.data
        etudiant = Utilisateur.query.filter_by(matricule=matricule, role='etudiant').first()

        if not etudiant:
            flash("Aucun étudiant trouvé avec ce matricule.", 'danger')
        else:
            notes = Note.query.filter_by(etudiant_id=etudiant.id).all()
    

    return render_template(
    'modifier_notes.html',
    form=form,
    etudiant=etudiant,
    notes=notes,
    matricule=matricule,
    csrf_token_value=generate_csrf()  # 👈 ajoute cette ligne
    )


@bp.route('/admin/export_csv', methods=['POST'])
@login_required
def exporter_resultats_csv():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    filiere = request.form.get('filiere')
    annee = request.form.get('annee')

    if not filiere or not annee:
        flash("Filière et année sont obligatoires.", 'danger')
        return redirect(url_for('main.admin_dashboard'))

    niveaux = ['1', '2', '3']  # ex: MI1, MI2, MI3 ou PC1, PC2, PC3
    zip_buffer = BytesIO()
    with zipfile.ZipFile(zip_buffer, 'w', zipfile.ZIP_DEFLATED) as zip_file:
        for niveau in niveaux:
            niveau_label = f"{filiere}{niveau}"  # génère MI1, PC2, etc.
            etudiants = Utilisateur.query.filter_by(role='etudiant', filiere=filiere, annee=niveau).all()

            if not etudiants:
                continue

            csv_buffer = BytesIO()
            text_stream = io.TextIOWrapper(csv_buffer, encoding='utf-8', newline='')
            writer = csv.writer(text_stream)
            writer.writerow(['Matricule', 'Nom', 'Matière', 'Type', 'Note', 'Crédit', 'Crédits obtenus', 'Statut'])

            for etu in etudiants:
                notes = Note.query.filter_by(etudiant_id=etu.id).all()
                credits_obtenus = sum(note.credit for note in notes if note.note >= 10)
                statut = "Admis" if credits_obtenus >= 48 else "Redoublant"

                if notes:
                    for note in notes:
                        writer.writerow([
                            etu.matricule,
                            etu.nom,
                            note.matiere,
                            note.type,
                            f"{note.note:.2f}",
                            note.credit,
                            credits_obtenus,
                            statut
                        ])
                else:
                    writer.writerow([
                        etu.matricule,
                        etu.nom,
                        "Aucune note",
                        "",
                        "",
                        "",
                        0,
                        "Redoublant"
                    ])

            text_stream.flush()
            csv_buffer.seek(0)
            zip_file.writestr(f"{niveau_label}_{annee}_resultats.csv", csv_buffer.read())

    zip_buffer.seek(0)
    return send_file(zip_buffer, as_attachment=True, download_name=f"{filiere}_{annee}_resultats.zip", mimetype='application/zip')
@bp.route('/a_propos')
def a_propos():
    return render_template('a_propos.html')


@bp.route('/contact', methods=['GET', 'POST'])
def contact():
    form = ContactForm()
    if form.validate_on_submit():
        nom = form.nom.data
        email = form.email.data
        message = form.message.data

        # Enregistrement du message dans la base de données
        nouveau_message = MessageContact(nom=nom, email=email, message=message)
        db.session.add(nouveau_message)
        db.session.commit()

        # Envoi de l'e-mail
        msg = Message("Nouveau message de contact",
                      recipients=['admin@example.com'])  # remplace par ton email
        msg.body = f"""
Vous avez reçu un nouveau message via le formulaire de contact :

Nom : {nom}
Email : {email}
Message :
{message}
"""
        mail.send(msg)

        flash("Merci pour votre message. Nous vous répondrons bientôt !", 'success')
        return redirect(url_for('main.contact'))

    return render_template('contact.html', form=form)


@bp.route('/admin/messages')
@login_required
def voir_messages():
    if current_user.role != 'admin':
        flash("Accès non autorisé.", 'danger')
        return redirect(url_for('main.login'))

    messages = MessageContact.query.order_by(MessageContact.date_envoi.desc()).all()
    return render_template("admin_messages.html", liste_messages=messages, csrf_token=generate_csrf())


@bp.route('/admin/message/<int:message_id>/repondre', methods=['POST'])
@login_required
def repondre_message(message_id):
    if current_user.role != 'admin':
        flash("Accès non autorisé.", "danger")
        return redirect(url_for('main.index'))

    message = MessageContact.query.get_or_404(message_id)
    reponse = request.form.get('reponse')
    message.reponse = reponse
    db.session.commit()

    # Envoi d’un email à l'étudiant
    msg_email = Message(
        subject="Réponse à votre message",
        sender='hounvosegbede@gmail.com',  # mail expéditeur
        recipients=[message.email],        # mail étudiant
        body=f"""
Bonjour {message.nom},

Voici la réponse de l'administrateur à votre message envoyé via le site :

Votre message :
{message.message}

Réponse :
{reponse}

Cordialement,
L’équipe administrative.
""")
    mail.send(msg_email)

    flash("Réponse envoyée avec succès à l'étudiant par mail.", "success")
    return redirect(url_for('main.voir_messages'))


@bp.route('/admin/message/<int:message_id>/delete', methods=['POST'])
@login_required
def supprimer_message(message_id):
    if current_user.role != 'admin':
        flash("Accès non autorisé.", "danger")
        return redirect(url_for('main.index'))

    message = MessageContact.query.get_or_404(message_id)
    db.session.delete(message)
    db.session.commit()
    flash("Message supprimé avec succès.", "success")
    return redirect(url_for('main.voir_messages'))