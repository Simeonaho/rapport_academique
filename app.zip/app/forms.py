from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, SelectField, FloatField, TextAreaField
from wtforms.validators import DataRequired, Email, EqualTo, Length, NumberRange, ValidationError
import re

class RegistrationForm(FlaskForm):
    matricule = StringField('Numéro matricule', validators=[DataRequired(), Length(min=6, max=20)])
    nom = StringField('Nom complet', validators=[DataRequired(), Length(min=2, max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    mot_de_passe = PasswordField('Mot de passe', validators=[DataRequired(), Length(min=8)])
    confirmer_mot_de_passe = PasswordField(
        'Confirmer le mot de passe',
        validators=[DataRequired(), EqualTo('mot_de_passe', message='Les mots de passe doivent correspondre.')]
    )
    submit = SubmitField("S'inscrire")

    def validate_mot_de_passe(self, field):
        password = field.data
        erreurs = []

        if len(password) < 8:
            erreurs.append("8 caractères minimum")
        if not re.search(r'[A-Z]', password):
            erreurs.append("1 majuscule")
        if not re.search(r'[a-z]', password):
            erreurs.append("1 minuscule")
        if not re.search(r'\d', password):
            erreurs.append("1 chiffre")
        if not re.search(r'[!@#$%^&*()\-_=+{};:,<.>]', password):
            erreurs.append("1 caractère spécial")

        if erreurs:
            raise ValidationError("Le mot de passe doit contenir : " + ", ".join(erreurs) + ".")

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    mot_de_passe = PasswordField('Mot de passe', validators=[DataRequired()])
    submit = SubmitField("Se connecter")

class AjouterEtudiantForm(FlaskForm):
    matricule = StringField('Matricule', validators=[DataRequired(), Length(min=6, max=20)])
    nom = StringField('Nom complet', validators=[DataRequired(), Length(min=2, max=50)])
    filiere = StringField('Filière', validators=[DataRequired(), Length(min=2, max=50)])
    annee = StringField('Année', validators=[DataRequired(), Length(min=1, max=10)])
    submit = SubmitField("Ajouter l'étudiant")

class AjouterNoteForm(FlaskForm):
    matricule = StringField("Matricule de l'étudiant", validators=[DataRequired(), Length(min=6, max=20)])
    matiere = StringField("Matière", validators=[DataRequired(), Length(min=2, max=100)])
    type = SelectField("Type", choices=[("UE", "UE"), ("EQ", "EQ")], validators=[DataRequired()])
    note = FloatField("Note", validators=[DataRequired(), NumberRange(min=0, max=20)])
    credit = FloatField("Crédit", validators=[DataRequired(), NumberRange(min=0)])
    submit = SubmitField("Ajouter la note")

class ContactForm(FlaskForm):
    nom = StringField('Nom', validators=[DataRequired(), Length(max=50)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    message = TextAreaField('Message', validators=[DataRequired(), Length(max=1000)])
    submit = SubmitField("Envoyer")
class ExportCSVForm(FlaskForm):
    filiere = StringField("Filière", validators=[DataRequired(), Length(min=1, max=10)])
    annee = StringField("Année académique", validators=[DataRequired(), Length(min=4, max=9)])
    submit = SubmitField("Télécharger les résultats")


class RechercheEtudiantForm(FlaskForm):
    matricule = StringField('Matricule', validators=[DataRequired()])
    submit = SubmitField('Rechercher')
