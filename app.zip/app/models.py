from app import db
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime  # Pour la date d'envoi des messages
import sqlalchemy as sa

class Utilisateur(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    matricule = db.Column(db.String(20), unique=True, nullable=False)
    nom = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=True)  # Rendu optionnel
    mot_de_passe_hash = db.Column(db.String(128), nullable=True)  # Rendu optionnel

    role = db.Column(db.String(20), nullable=False, default='etudiant')
    filiere = db.Column(db.String(50), nullable=True)
    annee = db.Column(db.String(10), nullable=True)

    notes = db.relationship('Note', backref='etudiant', lazy=True)

    def set_password(self, mot_de_passe):
        self.mot_de_passe_hash = generate_password_hash(mot_de_passe)

    def check_password(self, mot_de_passe):
        return check_password_hash(self.mot_de_passe_hash, mot_de_passe)

class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    matiere = db.Column(db.String(100), nullable=False)
    type = db.Column(db.String(10), nullable=False)  # UE ou EQ
    note = db.Column(db.Float, nullable=False)
    credit = db.Column(db.Float, nullable=False)
    etudiant_id = db.Column(db.Integer, db.ForeignKey('utilisateur.id'), nullable=False)

class MessageContact(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    message = db.Column(db.Text, nullable=False)
    date_envoi = db.Column(db.DateTime, server_default=sa.func.now())
    reponse = db.Column(db.Text, nullable=True)  # ✅ Champ ajouté



from app import login_manager

@login_manager.user_loader
def load_user(user_id):
    return Utilisateur.query.get(int(user_id))
