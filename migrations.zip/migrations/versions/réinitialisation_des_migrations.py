"""Réinitialisation des migrations"""

from alembic import op
import sqlalchemy as sa

# Révision de la migration
revision = '8349218622c0'
down_revision = None  # Cette migration est la première

def upgrade():
    # Crée les tables à partir des modèles si elles n'existent pas déjà
    op.create_table(
        'utilisateur',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('matricule', sa.String(length=20), nullable=False),
        sa.Column('nom', sa.String(length=50), nullable=False),
        sa.Column('email', sa.String(length=120), nullable=True),  # Rendu optionnel
        sa.Column('mot_de_passe_hash', sa.String(length=128), nullable=False),
        sa.Column('role', sa.String(length=20), nullable=False, default='etudiant'),
        sa.Column('filiere', sa.String(length=50), nullable=True),
        sa.Column('annee', sa.String(length=10), nullable=True),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('matricule'),
        sa.UniqueConstraint('email')
    )

    op.create_table(
        'note',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('matiere', sa.String(length=100), nullable=False),
        sa.Column('type', sa.String(length=10), nullable=False),  # UE ou EQ
        sa.Column('note', sa.Float(), nullable=False),
        sa.Column('credit', sa.Float(), nullable=False),
        sa.Column('etudiant_id', sa.Integer(), nullable=False),
        sa.ForeignKeyConstraint(['etudiant_id'], ['utilisateur.id'], ),
        sa.PrimaryKeyConstraint('id')
    )


def downgrade():
    op.drop_table('note')
    op.drop_table('utilisateur')
