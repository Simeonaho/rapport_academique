from alembic import op
import sqlalchemy as sa

# Identifiants de révision
revision = '0390a3f947bc'
down_revision = 'c97918edb6c5'
branch_labels = None
depends_on = None

def upgrade():
    pass

def downgrade():
    op.drop_column('message_contact', 'reponse')

