"""Suppression de l'ALTER sur mot_de_passe_hash (SQLite incompatible)

Revision ID: c7a33aada9ed
Revises: 8349218622c0
Create Date: 2025-05-23 02:11:07.700485

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c7a33aada9ed'
down_revision = '8349218622c0'
branch_labels = None
depends_on = None


def upgrade():
    # Aucune opération car ALTER COLUMN NOT NULL est incompatible avec SQLite
    pass


def downgrade():
    # Rien à faire non plus ici
    pass
