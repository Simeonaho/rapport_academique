"""Ajout de la table message_contact

Revision ID: c97918edb6c5
Revises: c7a33aada9ed
Create Date: 2025-05-27 01:24:33.080918

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = 'c97918edb6c5'
down_revision = 'c7a33aada9ed'
branch_labels = None
depends_on = None

def upgrade():
    # Suppression de l'instruction create_table car la table existe déjà
    pass



def downgrade():
    # Ne rien faire, la suppression est ignorée
    pass

